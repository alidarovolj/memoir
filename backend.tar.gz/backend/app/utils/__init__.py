"""Utility functions"""

