"""Database configuration and session management"""

